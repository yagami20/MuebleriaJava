/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.muebleriaAlvarezWSAcdatos;

import com.muebleriaalvarez.clases.Cliente;
import com.muebleriaalvarez.clases.Clientes;
import com.muebleriaalvarez.clases.Categoria;
import com.muebleriaalvarez.clases.Categorias;
import com.muebleriaalvarez.clases.Color;
import com.muebleriaalvarez.clases.Colores;
import com.muebleriaalvarez.clases.DetallePedidos;
import com.muebleriaalvarez.clases.Empleado;
import com.muebleriaalvarez.clases.Empleados;
import com.muebleriaalvarez.clases.Factura;
import com.muebleriaalvarez.clases.Facturas;
import com.muebleriaalvarez.clases.FechaPedido;
import com.muebleriaalvarez.clases.FechaPedidos;
import com.muebleriaalvarez.clases.Material;
import com.muebleriaalvarez.clases.Materiales;
import com.muebleriaalvarez.clases.Producto;
import com.muebleriaalvarez.clases.Productos;
import com.muebleriaalvarez.clases.Proveedor;
import com.muebleriaalvarez.clases.Proveedores;
import com.muebleriaalvarez.clases.TipoEmpleado;
import com.muebleriaalvarez.clases.cConexionAcdatos;
import com.muebleriaalvarez.clases.encriptacion;
import java.util.ArrayList;
import javax.crypto.Cipher;
import javax.jws.WebService;
import javax.jws.WebMethod;

/**
 *
 * @author WinUser
 */
@WebService(serviceName = "muebleriaAlvarezWSAcdatos")
public class muebleriaAlvarezWSAcdatos {

    
    @WebMethod(operationName = "registrarProductoAcdatos")
    public String registrarProductoAcdatos(Producto oProducto) {
        Productos oProductos=new Productos();
        return oProductos.registrarProducto(oProducto);
    }
    
    @WebMethod(operationName = "registrarCategoriaAcdatos")
    public String registrarCategoriaAcdatos(Categoria oCategoria) {
        Categorias oCategorias=new Categorias();
        return oCategorias.registrarCategoria(oCategoria);
    }
    
    @WebMethod(operationName = "listarCategoriaAD")
    public ArrayList<Categoria> listarCategoriaAD()
    {
        Categorias oCategoriaAcdatos = new Categorias();
        return oCategoriaAcdatos.listarCategoria();
    }
    @WebMethod(operationName = "listarColorAD")
    public ArrayList<Color> listarColorAD()
    {
        Colores oColorAcdatos = new Colores();
        return oColorAcdatos.listarColor();
    }
    @WebMethod(operationName = "listarMaterialAD")
    public ArrayList<Material> listarMaterialAD()
    {
        Materiales oMaterialAcdatos = new Materiales();
        return oMaterialAcdatos.listarMaterial();
    }
    
    @WebMethod(operationName = "IngresarCliente")
    public String IngresarCliente(Cliente oC)
    {
        Clientes oClientes = new Clientes();
        return oClientes.ingresarCliente(oC);
    }
    
     @WebMethod(operationName = "getClientesADWS")
    public ArrayList<Cliente> getClienteADWS() {
        Clientes es = new Clientes();
        es.loadClientes();
        return es.getclientes();
    }
    
    @WebMethod(operationName = "BuscarClientesADWS")
    public Cliente BuscarClientesADWS(String cedula) {
        Clientes es = new Clientes();
        return es.BuscarClientes(cedula);
    }
    
    
       @WebMethod(operationName = "EliminarClientesADWS")
    public String EliminarClientesADWS(String cedula) {
        Clientes es = new Clientes();
        return es.EliminarClientes(cedula);
    }
    
     @WebMethod(operationName = "modificardatosclientes")
    public String modificardatosclientes(Cliente ocliente) {
        Clientes oclientes=new Clientes();
        return oclientes.modicarcliente(ocliente);
    }
    
    @WebMethod(operationName = "listarProductosAD")
    public ArrayList<Producto> listarProductosAD()
    {
        Productos oproducto = new Productos();
        return oproducto.listarProdustos();
    }
  
    

            
    @WebMethod(operationName = "listarProductosStockminimoAD")
    public ArrayList<Producto> listarProductosStockminimoAD(Integer stock)
    {
        Productos oproducto = new Productos();
        return oproducto.listarProductosStockminimo(stock);
    }
    
      @WebMethod(operationName = "ContarProductosPedidosAD")
    public Integer ContarProductosPedidosAD(String codigoproducto) {
        DetallePedidos oDetallePedidos=new DetallePedidos();
        return oDetallePedidos.contarNumeroProductos(codigoproducto);
    }
   
     @WebMethod(operationName = "buscarProductosCodigoAD")
    public Producto buscarProductosCodigoAD(String codigoProducto) {
        Productos oproducto = new Productos();
        return oproducto.buscarProdustosCodigo(codigoProducto);
    }
    
     @WebMethod(operationName = "modificarDatosProductosAC")
    public String modificarDatosProductosAC(Producto oproducto) {
        Productos oproductos =new Productos();
        return oproductos.modicarProductos(oproducto);
    }
    
     @WebMethod(operationName = "eliminarProductoCambioAD")
    public String eliminarProductoCambioAD(String codigoProducto) {
        Productos oproducto = new Productos();
        return oproducto.eliminarProductoCambio(codigoProducto);
    }
    
      @WebMethod(operationName = "eliminarProductoAD")
    public String eliminarProductoAD(String codigoProducto) {
        Productos oproducto = new Productos();
        return oproducto.eliminarProducto(codigoProducto);
    }
    
      @WebMethod(operationName = "listarEmpleadosAD")
    public ArrayList<Empleado> listarEmpleadosAD()
    {
        Empleados oempleado=new Empleados();
        return oempleado.listarEmpleados();
    }
    
        @WebMethod(operationName = "eliminarEmpleadoAD")
    public String eliminarEmpleadoAD(String cedula) {
         Empleados oempleado=new Empleados();
        return oempleado.eliminarEmpleados(cedula);
    }
    
    
     @WebMethod(operationName = "buscarEmpleadoCodigoAD")
    public Empleado buscarEmpleadoCodigoAD(String cedula) {
        Empleados oempleado = new Empleados();
        return oempleado.buscarEmpleado(cedula);
    }
    
      @WebMethod(operationName = "ingresarEmpleado")
    public String ingresarEmpleado(Empleado oE)
    {
        Empleados oEs= new Empleados();
        return oEs.ingresarEmpleado(oE);
    }
    
    @WebMethod(operationName = "listarTipoEmpleado")
    public ArrayList<Empleado> listarTipoEmpleado()
    {
        TipoEmpleado oTE = new TipoEmpleado();
        return oTE.listarEmpleado();
    }
    
       @WebMethod(operationName = "listarPedidosfechaAD")
    public ArrayList<FechaPedido> listarPedidosfechaAD(String fecha)
    {
        FechaPedidos oempleado=new FechaPedidos();
        return oempleado.listarPedidosporfecha(fecha);
    }
    
        @WebMethod(operationName = "VerificarConexionAD")
    public Boolean VerificarConexionAD()
    {
        cConexionAcdatos oconexion=new cConexionAcdatos();
        return oconexion.conectar();
    }
    
       @WebMethod(operationName = "auntentificarClienteAD")
    public Cliente auntentificarClienteAD(String cedula, String clave) {
        Clientes ocliente = new Clientes();
        return ocliente.autentificacionCliente(cedula, clave);
    }
    
       @WebMethod(operationName = "encriptarAD")
    public String encriptarAD(String key,String iv,String contrasena) throws Exception {
        encriptacion oencriptar = new encriptacion();
       return oencriptar.encriptar(key, iv,contrasena);
    }
    
       @WebMethod(operationName = "desencriptarAD")
    public String desencriptarAD(String key,String iv,String desencriptar) throws Exception {
        encriptacion odesencriptar = new encriptacion();
        return odesencriptar.desencriptar(key, iv,desencriptar);
    }
    
     @WebMethod(operationName = "ingresarFacturaAD")
    public String ingresarFacturaAD(Factura oFactura) 
    {
        Facturas oFacturas=new Facturas();
        return oFacturas.ingresarFactura(oFactura);
    }
    
    
      @WebMethod(operationName = "ingresarProveedorAD")
    public String ingresarProveedorAD(Proveedor oP)
    {
        Proveedores oPs= new Proveedores();
        return oPs.ingresarProveedor(oP);
    }
    
    @WebMethod(operationName = "modificarEmpleadoAD")
    public String modificarEmpleadoAD(Empleado oEmpleado) {
        Empleados oe=new Empleados();
        return oe.modificarEmpleado(oEmpleado);
    }

    //empleado
      @WebMethod(operationName = "auntentificarEmpleadoAD")
    public Empleado auntentificarEmpleadoAD(String cedula, String clave, Integer idtipo) {
        Empleados oEmpleado = new Empleados();
        return oEmpleado.autentificacionEmpleado(cedula, clave, idtipo);
    }
}
