/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.muebleriaalvarez.basedatos;

/**
 *
 * @author User
 */
public class conexion {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        cBaseDatos o = new cBaseDatos();
       /* boolean valor=true;
         if (o.conectar().equals(valor)){
           System.out.println ("Conexión a la base de datos exitosa");
    }
         else
         {
         System.out.println ("No se pudo realizar la conexión");
         }*/
       // String strSql = "select count(*) from tbldetallepedido  WHERE codproducto='NMBNmj';";
       // System.out.println (o.valores(strSql));
               
    }
    
}
