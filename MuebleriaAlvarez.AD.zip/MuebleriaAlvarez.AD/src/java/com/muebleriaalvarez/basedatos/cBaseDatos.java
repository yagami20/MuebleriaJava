/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.muebleriaalvarez.basedatos;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Jennifer Naveda
 */
public class cBaseDatos {

    private Connection cnn = null;
    private Exception err = null;
    private ResultSet rs;
    Statement st;
    
    public cBaseDatos() {
        this.cnn = null;
        this.err = null;
    }

    public Boolean conectar() {
        Boolean result = false;
        try {
            Class.forName("org.postgresql.Driver");
            Properties prp = new Properties();
            prp.setProperty("user", "postgres");
            prp.setProperty("password","password");
            String url = "jdbc:postgresql://192.168.172.128:5432/BDAlvarez";
            this.cnn = DriverManager.getConnection(url, prp);
            
                
                    
                  result = true;
        } catch (ClassNotFoundException | SQLException e) {
            this.err = e;
        }
        return result;
    }
    
    
    public ResultSet execSQL(String strSQL) {
        Statement stmt;
        try {
            if (this.cnn == null) {
                this.conectar();
            }
            if (this.cnn != null) {
                stmt = this.cnn.createStatement();
                rs = stmt.executeQuery(strSQL);
            }
        } catch (SQLException ex) {
            Logger.getLogger(cBaseDatos.class.getName()).log(Level.SEVERE, null, ex);
        }

        return rs;
    }
    public Boolean execUpdate(String strSQL) {
      
        Boolean result = false;
        try {
            if (this.cnn == null) {
                this.conectar();
            }
            if (this.cnn != null) {
                PreparedStatement stm = this.cnn.prepareStatement(strSQL);
                stm.executeUpdate();
              
            result = true;
            }
        } catch (SQLException ex) {
            Logger.getLogger(cBaseDatos.class.getName()).log(Level.SEVERE, null, ex);
        }

        return result;
    }
    
    
}
