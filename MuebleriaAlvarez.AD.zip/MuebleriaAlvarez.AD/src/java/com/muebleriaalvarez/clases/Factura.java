/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.muebleriaalvarez.clases;

/**
 *
 * @author Erika Reina
 */
public class Factura extends Cliente {
    private Integer idFactura;
    private String fechFactura;
    private Integer idEstad=1;
    private String nomEstad="EMITIDA";
    private Integer porDescuento;
    private Double descuento;
    private Double igv;
    private Double subTotal;
    private Double totalpagar;

    
    
    
    public Integer getIdFactura() {
        return idFactura;
    }

    public void setIdFactura(Integer idFactura) {
        this.idFactura = idFactura;
    }

    public String getFechFactura() {
        return fechFactura;
    }

    public void setFechFactura(String fechFactura) {
        this.fechFactura = fechFactura;
    }

    public Integer getIdEstad() {
        return idEstad;
    }

    public void setIdEstad(Integer idEstad) {
        this.idEstad = idEstad;
    }

    public Integer getPorDescuento() {
        return porDescuento;
    }

    public void setPorDescuento(Integer porDescuento) {
        this.porDescuento = porDescuento;
    }

    public Double getDescuento() {
        return descuento;
    }

    public void setDescuento(Double descuento) {
        this.descuento = descuento;
    }

    public Double getIgv() {
        return igv;
    }

    public void setIgv(Double igv) {
        this.igv = igv;
    }

    public Double getSubTotal() {
        return subTotal;
    }

    public void setSubTotal(Double subTotal) {
        this.subTotal = subTotal;
    }

    public Double getTotalpagar() {
        return totalpagar;
    }

    public void setTotalpagar(Double totalpagar) {
        this.totalpagar = totalpagar;
    }

    public String getNomEstad() {
        return nomEstad;
    }

    public void setNomEstad(String nomEstad) {
        this.nomEstad = nomEstad;
    }
    
    
}
