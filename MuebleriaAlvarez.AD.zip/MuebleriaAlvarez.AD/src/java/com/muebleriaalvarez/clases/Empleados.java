/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.muebleriaalvarez.clases;

import com.muebleriaalvarez.basedatos.cBaseDatos;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;


/**
 *
 * @author User
 */
public class Empleados {
    
   private cBaseDatos bd;
   private cBaseDatos cBaseDatos;
    private ArrayList<Empleado> arrayEmpleados;

   public Empleados(){
   
   }
   
   
    public String ingresarEmpleado(Empleado oEmpleado)
        {
        String strResult="error";
        int band=0;
        if (this.bd == null) {
            this.bd = new cBaseDatos();
        }
         
        String srtSql="SELECT cedulaempleado FROM tblempleado WHERE cedulaempleado='"+oEmpleado.getCedula()+"';";
        ResultSet rs=this.bd.execSQL(srtSql);
        if(rs!=null)
        {
            try{
                while(rs.next())
                {
                    band=band+1;
                }
            }catch (SQLException ex) {
                Logger.getLogger(Empleados.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
         if(band>=1)
         {
             strResult="si existe";
         }
         else
         {
        if(oEmpleado.CalcularEdad(oEmpleado.getFechaNacimiento())>=18)
        {
         String sql = "INSERT INTO tblempleado(cedulaempleado,nombempleado,apellempleado,direcempleado,fechanac,telefempleado,salario,idtipempleado,correoempleado,claveempleado,estado) VALUES ('"+oEmpleado.getCedula()+"','"+oEmpleado.getNombre()+"','"+oEmpleado.getApellido()+"','"+oEmpleado.getDireccion()+"','"+oEmpleado.getFechaNacimiento()+"','"+oEmpleado.getTelefono()+"','"+oEmpleado.getSalario()+"','"+oEmpleado.getTipo()+"','"+oEmpleado.getCorreo()+"','"+oEmpleado.getClave()+"','ACTIVO');";
         
                  
            if (this.bd.execUpdate(sql))
            {
                //if(this.cBaseDatos.execUpdate(sql1))
                //{
                    strResult = "Empleado Ingresado";
                //}
            }
            else
            {
                strResult = "No hay conexion con la base de datos";
            }
         }
        else
            {
                strResult = "Menor de Edad";
            }
            
         }
        return strResult;
        }
    
   
     
public ArrayList<Empleado> listarEmpleados() {
          this.arrayEmpleados=null;
        if (this.bd == null)
        {
            this.bd = new cBaseDatos();
        }
        
        String sql = "SELECT * FROM tblempleado where estado='ACTIVO';";
        ResultSet rs = this.bd.execSQL(sql);
        if (rs != null) {
            this.arrayEmpleados = new ArrayList<>();
            try {
                while (rs.next()) {
                    Empleado oempleado = new Empleado();
                    oempleado.setCedula(rs.getString("cedulaempleado"));
                    oempleado.setNombre(rs.getString("nombempleado"));
                    oempleado.setApellido(rs.getString("apellempleado"));
                    oempleado.setDireccion(rs.getString("direcempleado"));
                    oempleado.setFechaNacimiento(rs.getString("fechanac"));
                    oempleado.setTelefono(rs.getString("telefempleado"));
                    oempleado.setSalario(rs.getDouble("salario"));
                    oempleado.setTipo(rs.getInt("idtipempleado"));
                    oempleado.setCorreo(rs.getString("correoempleado"));
                    oempleado.setClave(rs.getString("claveempleado"));
                    oempleado.setEstado(rs.getString("estado"));

                    this.arrayEmpleados.add(oempleado);
                }
            } catch (SQLException ex) {
                Logger.getLogger(Materiales.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return this.arrayEmpleados;
    }


     
     
    
    public String eliminarEmpleados(String cedula) {
        if (this.bd == null) {
            this.bd = new cBaseDatos();
        }

        String strSql = "DELETE FROM tblempleado  WHERE cedulaempleado='" + cedula + "';";
        String strResult;

        if (this.bd.execUpdate(strSql)) {
            strResult = "Cliente eliminado";
        } else {
            strResult = "No hay conexión con la base de datos";
        }
        return strResult;
    }
    
    
    public Empleado buscarEmpleado(String cedula) {

        if (this.bd == null) {
            this.bd = new cBaseDatos();
        }

        Empleado oempleado = null;

        String sql = "SELECT * FROM tblempleado WHERE cedulaempleado='" + cedula + "'";
        ResultSet rs = this.bd.execSQL(sql);
        if (rs != null) {

            try {
                oempleado = new Empleado();
                while (rs.next()) {
                   oempleado.setCedula(rs.getString("cedulaempleado"));
                    oempleado.setNombre(rs.getString("nombempleado"));
                    oempleado.setApellido(rs.getString("apellempleado"));
                    oempleado.setDireccion(rs.getString("direcempleado"));
                    oempleado.setFechaNacimiento(rs.getString("fechanac"));
                    oempleado.setTelefono(rs.getString("telefempleado"));
                    oempleado.setSalario(rs.getDouble("salario"));
                    oempleado.setTipo(rs.getInt("idtipempleado"));
                    oempleado.setCorreo(rs.getString("correoempleado"));
                    oempleado.setClave(rs.getString("claveempleado"));
                    oempleado.setEstado(rs.getString("estado"));
                }
            } catch (SQLException ex) {
                Logger.getLogger(Clientes.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return oempleado;
    }
    
    public String modificarEmpleado(Empleado oEmpleado) {

        if (this.bd == null) {
            this.bd = new cBaseDatos();
        }
        String strResult;

        String Sql = "UPDATE tblempleado SET nombempleado='" + oEmpleado.getNombre() + "', apellempleado='" + oEmpleado.getApellido() + "', direcempleado='" + oEmpleado.getDireccion() + "', fechanac='" + oEmpleado.getFechaNacimiento() + "', telefempleado='" + oEmpleado.getTelefono() + "', salario='" + oEmpleado.getSalario() + "', idtipempleado='"+ oEmpleado.getTipo()+"', correoempleado='" + oEmpleado.getCorreo() + "', claveempleado='" + oEmpleado.getClave() + "' WHERE cedulaempleado='" + oEmpleado.getCedula() + "';";

        if (this.bd.execUpdate(Sql)) {
            strResult = "Empleado Modificado Correctamente";
        } else {
            strResult = "No se pudo modificar al Empleado";
        }
        return strResult;
    }

    //autentificar
     public Empleado autentificacionEmpleado(String cedula, String clave, Integer idtipo) {

     
        if (this.cBaseDatos == null) {
            this.cBaseDatos = new cBaseDatos();
        }

        Empleado e = null;
        
        String sql="SELECT * FROM tblempleado WHERE cedulaempleado='" + cedula + "'and claveempleado='" + clave + "'and idtipempleado='" + idtipo + "'";

        
        ResultSet rs = this.cBaseDatos.execSQL(sql);
        if (rs != null) {

            try {
                
                while (rs.next()) {
                    Empleado oempleado = new Empleado();
                    oempleado.setCedula(rs.getString("cedulaempleado"));
                    oempleado.setNombre(rs.getString("nombempleado"));
                    oempleado.setApellido(rs.getString("apellempleado"));
                    oempleado.setDireccion(rs.getString("direcempleado"));
                    oempleado.setFechaNacimiento(rs.getString("fechanac"));
                    oempleado.setTelefono(rs.getString("telefempleado"));
                    oempleado.setSalario(rs.getDouble("salario"));
                    oempleado.setTipo(rs.getInt("idtipempleado"));
                    oempleado.setCorreo(rs.getString("correoempleado"));
                    oempleado.setClave(rs.getString("claveempleado"));
                    oempleado.setEstado(rs.getString("estado"));
                    
                }
            } catch (SQLException ex) {
                Logger.getLogger(Clientes.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return e;
    }
}
