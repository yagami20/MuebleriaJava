/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.muebleriaalvarez.clases;

import com.muebleriaalvarez.basedatos.cBaseDatos;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author WinUser
 */
public class Categorias {
    private cBaseDatos Bd;
    private ArrayList<Categoria> ArralCategorias;
    
     public Categorias(){}
     
     public ArrayList<Categoria> listarCategoria()
    {
        this.ArralCategorias=null;
        if (this.Bd == null)
        {
            this.Bd = new cBaseDatos();
        }
        
        String sql = "SELECT * FROM tblcategoria";
        ResultSet rs = this.Bd.execSQL(sql);
        if(rs != null )
        {
            this.ArralCategorias = new ArrayList<>();
            try
            {
               while(rs.next()) 
               {
                   Categoria oCategoria = new Categoria();
                   oCategoria.setIdCategoria(rs.getInt("idcategoria"));
                   oCategoria.setNombreCategoria(rs.getString("nombecategoria"));
                   
                   this.ArralCategorias.add(oCategoria);
               }
            }
            catch (SQLException ex) 
            {
                Logger.getLogger(Categorias.class.getName()).log(Level.SEVERE, null, ex);                       
            }
        }
      return this.ArralCategorias;
    }
     
       public String registrarCategoria(Categoria ocategoria)
    {
        String strResult;
        if (this.Bd == null) {
            this.Bd = new cBaseDatos();
        }
        
        String sql = "INSERT INTO tblcategoria (nombecategoria) VALUES ('"+ocategoria.getNombreCategoria()+"')";
        if(this.Bd.execUpdate(sql))
        {
            strResult = "Producto Ingresado Correctamente";
        }
        else
        {
            strResult = "Productos Duplicados";
        }
        return strResult;
    }
}
