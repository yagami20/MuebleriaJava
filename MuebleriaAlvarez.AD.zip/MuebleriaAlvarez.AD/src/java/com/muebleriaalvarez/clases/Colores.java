/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.muebleriaalvarez.clases;

import com.muebleriaalvarez.basedatos.cBaseDatos;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author WinUser
 */
public class Colores {
    private cBaseDatos Bd;
    private ArrayList<Color> ArralColores;
    
    public Colores(){}
    
   public ArrayList<Color> listarColor()
    {
        this.ArralColores=null;
        if (this.Bd == null)
        {
            this.Bd = new cBaseDatos();
        }
        
        String sql = "SELECT * FROM tblcolor";
        ResultSet rs = this.Bd.execSQL(sql);
        if(rs != null )
        {
            this.ArralColores = new ArrayList<>();
            try
            {
               while(rs.next()) 
               {
                   Color oColor = new Color();
                   oColor.setIdColor(rs.getInt("Idcolor"));
                   oColor.setNombreColor(rs.getString("nombcolor"));
                   
                   this.ArralColores.add(oColor);
               }
            }
            catch (SQLException ex) 
            {
                Logger.getLogger(Colores.class.getName()).log(Level.SEVERE, null, ex);                       
            }
        }
      return this.ArralColores;
    } 
}
