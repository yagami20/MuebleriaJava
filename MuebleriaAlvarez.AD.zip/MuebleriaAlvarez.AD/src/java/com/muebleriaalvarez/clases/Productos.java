/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.muebleriaalvarez.clases;

import com.muebleriaalvarez.basedatos.cBaseDatos;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Jennifer
 */
public class Productos{
    
    private cBaseDatos bd;
    private ArrayList<Producto> productos;
    
    public String registrarProducto(Producto oProducto)
    {
        String strResult;
        if (this.bd == null) {
            this.bd = new cBaseDatos();
        }
        
        String sql = "INSERT INTO tblproducto VALUES (default,'"+oProducto.getNombreProducto()+"','"+oProducto.getPrecioProducto()+"','"+oProducto.getDescripcionProducto()+"','"+oProducto.getStockProducto()+"','"+oProducto.getCategoriaProducto()+"','"+oProducto.getColorProducto()+"','"+oProducto.getMaterialProducto()+"','"+oProducto.getCodigoProducto()+"','ACTIVO')";
        if(this.bd.execUpdate(sql))
        {
            strResult = "Producto Ingresado Correctamente";
        }
        else
        {
            strResult = "Producto Duplicado";
        }
        return strResult;
    }
    
    public ArrayList<Producto> listarProdustos() {
        this.productos = null;
        if (this.bd == null) {
            this.bd = new cBaseDatos();
        }

        String sql = "SELECT tblproducto.nombproducto,tblproducto.idproducto, tblproducto.precioproducto, tblproducto.stockproducto,tblproducto.codigoproducto,  tblcolor.nombcolor, tblmaterial.nombmaterial, tblcategoria.nombecategoria,tblproducto.idcolorprod,  tblproducto.idmatprod,  tblproducto.idcatprod,tblproducto.descproducto,tblproducto.estado FROM tblproducto inner join tblcolor on tblcolor.idcolor=tblproducto.idcolorprod inner join tblcategoria on tblproducto.idcatprod=tblcategoria.idcategoria inner join tblmaterial on tblmaterial.idmaterial=tblproducto.idmatprod WHERE tblproducto.estado='ACTIVO' ;";
        ResultSet rs = this.bd.execSQL(sql);
        if (rs != null) {
            this.productos = new ArrayList<>();
            try {
                while (rs.next()) {
                    Producto oproducto = new Producto();
                    oproducto.setIdProducto(rs.getInt("idproducto"));
                    oproducto.setNombreProducto(rs.getString("nombproducto"));
                    oproducto.setPrecioProducto(rs.getDouble("precioproducto"));
                    oproducto.setDescripcionProducto(rs.getString("descproducto"));
                    oproducto.setStockProducto(rs.getInt("stockproducto"));
                    oproducto.setCategoriaProducto(rs.getInt("idcatprod"));
                    oproducto.setColorProducto(rs.getInt("idcolorprod"));
                    oproducto.setMaterialProducto(rs.getInt("idmatprod"));
                    oproducto.setCodigoproducto(rs.getString("codigoproducto"));
                    oproducto.setEstado(rs.getString("estado"));
                    oproducto.setNombreCategoria(rs.getString("nombecategoria"));
                    oproducto.setNombreColor(rs.getString("nombcolor"));
                    oproducto.setNombreMaterial(rs.getString("nombmaterial"));
                    
                    this.productos.add(oproducto);
                }
            } catch (SQLException ex) {
                Logger.getLogger(Materiales.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return this.productos;
    }

    
    
    public Producto buscarProdustosCodigo(String codproducto) {
        this.productos = null;
        if (this.bd == null) {
            this.bd = new cBaseDatos();
        }
        
         Producto oproducto = null;

        String sql = "SELECT tblproducto.nombproducto,tblproducto.idproducto, tblproducto.precioproducto, tblproducto.stockproducto,tblproducto.codigoproducto,  tblcolor.nombcolor, tblmaterial.nombmaterial, tblcategoria.nombecategoria,tblproducto.idcolorprod,  tblproducto.idmatprod,  tblproducto.idcatprod,tblproducto.descproducto,tblproducto.estado FROM tblproducto inner join tblcolor on tblcolor.idcolor=tblproducto.idcolorprod inner join tblcategoria on tblproducto.idcatprod=tblcategoria.idcategoria inner join tblmaterial on tblmaterial.idmaterial=tblproducto.idmatprod WHERE tblproducto.estado='ACTIVO' AND tblproducto.codigoproducto='"+codproducto+"';";
        ResultSet rs = this.bd.execSQL(sql);
        if (rs != null) {
            this.productos = new ArrayList<>();
            try {
                while (rs.next()) {
                    oproducto = new Producto();
                    oproducto.setIdProducto(rs.getInt("idproducto"));
                    oproducto.setNombreProducto(rs.getString("nombproducto"));
                    oproducto.setPrecioProducto(rs.getDouble("precioproducto"));
                    oproducto.setDescripcionProducto(rs.getString("descproducto"));
                    oproducto.setStockProducto(rs.getInt("stockproducto"));
                    oproducto.setCategoriaProducto(rs.getInt("idcatprod"));
                    oproducto.setColorProducto(rs.getInt("idcolorprod"));
                    oproducto.setMaterialProducto(rs.getInt("idmatprod"));
                    oproducto.setCodigoproducto(rs.getString("codigoproducto"));
                    oproducto.setEstado(rs.getString("estado"));
                    oproducto.setNombreCategoria(rs.getString("nombecategoria"));
                    oproducto.setNombreColor(rs.getString("nombcolor"));
                    oproducto.setNombreMaterial(rs.getString("nombmaterial"));
                  
                }
            } catch (SQLException ex) {
                Logger.getLogger(Materiales.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return oproducto;
    }
    
    
    public String eliminarProductoCambio(String codigoProducto)
    {
        String strResult;
        if (this.bd == null) {
            this.bd = new cBaseDatos();
        }
        
        String sql = "UPDATE tblproducto SET estado='PASIVO' WHERE codigoproducto='" + codigoProducto + "';";
        if(this.bd.execUpdate(sql))
        {
            strResult = "Cliente Modificado Correctamente";
        }
        else
        {
            strResult = "No se pudo modificar al cliente";
        }
        return strResult;
    }
    
    
    public String eliminarProducto(String codigoProducto) {
        if (this.bd == null) {
            this.bd = new cBaseDatos();
        }

        String strSql = "DELETE FROM tblproducto  WHERE codigoproducto='" + codigoProducto + "';";
        String strResult;

        if (this.bd.execUpdate(strSql)) {
            strResult = "Producto eliminado";
        } else {
            strResult = "No hay conexión con la base de datos";
        }
        return strResult;
    }

    
    public String modicarProductos(Producto oproducto)
    {
        String strResult;
        if (this.bd == null) {
            this.bd = new cBaseDatos();
        }
        
        String sql = "UPDATE tblproducto SET nombproducto='"+oproducto.getNombreProducto()+"',precioproducto='"+oproducto.getPrecioProducto()+"',descproducto='"+oproducto.getDescripcionProducto()+"' ,stockproducto='"+oproducto.getStockProducto()+"',idcatprod='"+oproducto.getCategoriaProducto()+"',idcolorprod='"+oproducto.getColorProducto()+"',idmatprod='"+oproducto.getMaterialProducto()+"' WHERE  codigoproducto='" + oproducto.getCodigoProducto()+ "';";
        if(this.bd.execUpdate(sql))
        {
            strResult = "Cliente Modificado Correctamente";
        }
        else
        {
            strResult = "No se pudo modificar al cliente";
        }
        return strResult;
    }
    
     public ArrayList<Producto> listarProductosStockminimo(Integer stock) {
        this.productos = null;
        if (this.bd == null) {
            this.bd = new cBaseDatos();
        }

        String sql = "SELECT tblproducto.nombproducto,tblproducto.idproducto, tblproducto.precioproducto, tblproducto.stockproducto,tblproducto.codigoproducto,  tblcolor.nombcolor, tblmaterial.nombmaterial, tblcategoria.nombecategoria,tblproducto.idcolorprod,  tblproducto.idmatprod,  tblproducto.idcatprod,tblproducto.descproducto,tblproducto.estado FROM tblproducto inner join tblcolor on tblcolor.idcolor=tblproducto.idcolorprod inner join tblcategoria on tblproducto.idcatprod=tblcategoria.idcategoria inner join tblmaterial on tblmaterial.idmaterial=tblproducto.idmatprod WHERE tblproducto.estado='ACTIVO' and tblproducto.stockproducto < '"+stock+"';";
        ResultSet rs = this.bd.execSQL(sql);
        if (rs != null) {
            this.productos = new ArrayList<>();
            try {
                while (rs.next()) {
                    Producto oproducto = new Producto();
                    oproducto.setIdProducto(rs.getInt("idproducto"));
                    oproducto.setNombreProducto(rs.getString("nombproducto"));
                    oproducto.setPrecioProducto(rs.getDouble("precioproducto"));
                    oproducto.setDescripcionProducto(rs.getString("descproducto"));
                    oproducto.setStockProducto(rs.getInt("stockproducto"));
                    oproducto.setCategoriaProducto(rs.getInt("idcatprod"));
                    oproducto.setColorProducto(rs.getInt("idcolorprod"));
                    oproducto.setMaterialProducto(rs.getInt("idmatprod"));
                    oproducto.setCodigoproducto(rs.getString("codigoproducto"));
                    oproducto.setEstado(rs.getString("estado"));
                    oproducto.setNombreCategoria(rs.getString("nombecategoria"));
                    oproducto.setNombreColor(rs.getString("nombcolor"));
                    oproducto.setNombreMaterial(rs.getString("nombmaterial"));
                    
                    this.productos.add(oproducto);
                }
            } catch (SQLException ex) {
                Logger.getLogger(Materiales.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return this.productos;
    }
    
}
