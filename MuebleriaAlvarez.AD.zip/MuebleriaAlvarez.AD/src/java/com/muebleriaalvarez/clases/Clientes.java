package com.muebleriaalvarez.clases;

import com.muebleriaalvarez.basedatos.cBaseDatos;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Clientes {

    private cBaseDatos cBaseDatos;
    private ArrayList<Cliente> Clientes;

    public ArrayList<Cliente> getclientes() {
        return this.Clientes;
    }

    public Clientes() {
    }
    /*
     public String ingresarCliente(Cliente oCliente)
     {
        
     String strResult;
     if (this.cBaseDatos == null) {
     this.cBaseDatos = new cBaseDatos();
     }
        
     String sql = "INSERT INTO tblcliente(cedulacliente,nombrecliente,apellido,direccliente,fechanac,telfcliente,correocliente,clavecliente) VALUES ('"+oCliente.getCedula()+"','"+oCliente.getNombre()+"','"+oCliente.getApellido()+"','"+oCliente.getDireccion()+"','"+oCliente.getFecha_Nacimiento()+"','"+oCliente.getTelefono()+"','"+oCliente.getCorreo()+"','"+oCliente.getClave()+"');";
     //String sql = "INSERT INTO cliente1(cedula) VALUES ('"+cad+"');";
     if (this.cBaseDatos.execUpdate(sql))
            
     {
     strResult = "Cliente Ingresado";
     }
     else
     {
     strResult = "No hay conexión con la base de datos";
     }
     return strResult;
     }*/

    public String ingresarCliente(Cliente oCliente)
        {
        String strResult ;
        int band=0;
        if (this.cBaseDatos == null) {
            this.cBaseDatos = new cBaseDatos();
        }
         
        String srtSql="SELECT cedulacliente FROM tblcliente WHERE cedulacliente='"+oCliente.getCedula()+"';";
        ResultSet rs=this.cBaseDatos.execSQL(srtSql);
        if(rs!=null)
        {
            try{
                while(rs.next())
                {
                    band=band+1;
                }
            }catch (SQLException ex) {
                Logger.getLogger(Clientes.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
         if(band>=1)
         {
             strResult="si existe";
         }
         else
         {
        if(CalcularEdad(oCliente.getFecha_Nacimiento())>=18)
        {
         String sql = "INSERT INTO tblcliente(cedulacliente,nombrecliente,apellido,direccliente,fechanac,telfcliente,correocliente,clavecliente,estado) VALUES ('"+oCliente.getCedula()+"','"+oCliente.getNombre()+"','"+oCliente.getApellido()+"','"+oCliente.getDireccion()+"','"+oCliente.getFecha_Nacimiento()+"','"+oCliente.getTelefono()+"','"+oCliente.getCorreo()+"','"+oCliente.getClave()+"','"+oCliente.getEstado()+"');";
         
         if (this.cBaseDatos.execUpdate(sql))
         {
            
                strResult = "Cliente Ingresado";
            
         }
            else
            {
                strResult = "No hay conexión con la base de datos";
            }
         }
        else
            {
                strResult = "Menor de Edad";
            }
            
         }
        return strResult;
        }

    public ArrayList<Cliente> listarclientes() {
        this.Clientes = null;
        if (this.cBaseDatos == null) {
            this.cBaseDatos = new cBaseDatos();
        }

        String sql = "SELECT * FROM tblmaterial ";
        ResultSet rs = this.cBaseDatos.execSQL(sql);
        if (rs != null) {
            this.Clientes = new ArrayList<>();
            try {
                while (rs.next()) {
                    Cliente ocliente = new Cliente();
                    ocliente.setCedula(rs.getString("cedulacliente"));
                    ocliente.setNombre(rs.getString("nombrecliente"));
                    ocliente.setApellido(rs.getString("apellido"));
                    ocliente.setDireccion(rs.getString("direccliente"));
                    ocliente.setFecha_Nacimiento(rs.getString("fechanac"));
                    ocliente.setTelefono(rs.getString("telfcliente"));
                    ocliente.setClave(rs.getString("clavecliente"));

                    this.Clientes.add(ocliente);
                }
            } catch (SQLException ex) {
                Logger.getLogger(Materiales.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return this.Clientes;
    }

    public ArrayList<Cliente> loadClientes() {
        this.Clientes = null;
        if (this.cBaseDatos == null) {
            this.cBaseDatos = new cBaseDatos();
        }

        String sql = "SELECT * FROM tblcliente WHERE estado='ACTIVO' order by apellido desc " ;
        ResultSet rs = this.cBaseDatos.execSQL(sql);
        if (rs != null) {
            this.Clientes = new ArrayList<>();
            try {
                while (rs.next()) {
                    Cliente e = new Cliente();

                    e.setCedula(rs.getString("cedulacliente"));
                    e.setNombre(rs.getString("nombrecliente"));
                    e.setApellido(rs.getString("apellido"));
                    e.setDireccion(rs.getString("direccliente"));
                    e.setFecha_Nacimiento(rs.getString("fechanac"));
                    e.setTelefono(rs.getString("telfcliente"));
                    e.setCorreo(rs.getString("correocliente"));
                    e.setClave(rs.getString("clavecliente"));
                    this.Clientes.add(e);
                }
            } catch (SQLException ex) {
                Logger.getLogger(Clientes.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return this.Clientes;
    }

    public Cliente BuscarClientes(String cedula) {

        if (this.cBaseDatos == null) {
            this.cBaseDatos = new cBaseDatos();
        }

        Cliente e = null;

        String sql = "SELECT * FROM tblcliente WHERE cedulacliente='" + cedula + "'";
        ResultSet rs = this.cBaseDatos.execSQL(sql);
        if (rs != null) {

            try {
                e = new Cliente();
                while (rs.next()) {
                    e.setCedula(rs.getString("cedulacliente"));
                    e.setNombre(rs.getString("nombrecliente"));
                    e.setApellido(rs.getString("apellido"));
                    e.setDireccion(rs.getString("direccliente"));
                    e.setFecha_Nacimiento(rs.getString("fechanac"));
                    e.setTelefono(rs.getString("telfcliente"));
                    e.setCorreo(rs.getString("correocliente"));
                    e.setClave(rs.getString("clavecliente"));
                }
            } catch (SQLException ex) {
                Logger.getLogger(Clientes.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return e;
    }

    public Cliente autentificacionCliente(String cedula, String clave) {

     
        if (this.cBaseDatos == null) {
            this.cBaseDatos = new cBaseDatos();
        }

        Cliente e = null;

        String sql = "SELECT * FROM tblcliente WHERE clavecliente='"+ clave+ "' and cedulacliente='" + cedula + "'";
        ResultSet rs = this.cBaseDatos.execSQL(sql);
        if (rs != null) {

            try {
                e = new Cliente();
                while (rs.next()) {
                    e.setCedula(rs.getString("cedulacliente"));
                    e.setNombre(rs.getString("nombrecliente"));
                    e.setApellido(rs.getString("apellido"));
                    e.setDireccion(rs.getString("direccliente"));
                    e.setFecha_Nacimiento(rs.getString("fechanac"));
                    e.setTelefono(rs.getString("telfcliente"));
                    e.setCorreo(rs.getString("correocliente"));
                    e.setClave(rs.getString("clavecliente"));
                }
            } catch (SQLException ex) {
                Logger.getLogger(Clientes.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return e;
    }

    
    
    public String EliminarClientes(String cedula) {
        if (this.cBaseDatos == null) {
            this.cBaseDatos = new cBaseDatos();
        }

        String strSql = "DELETE FROM tblcliente  WHERE cedulacliente='" + cedula + "';";
        String strResult;

        if (this.cBaseDatos.execUpdate(strSql)) {
            strResult = "Cliente eliminado";
        } else {
            strResult = "No hay conexión con la base de datos";
        }
        return strResult;
    }
    
    public String modicarcliente(Cliente ocliente)
    {
        String strResult;
        if (this.cBaseDatos == null) {
            this.cBaseDatos = new cBaseDatos();
        }
        
        String sql = "UPDATE tblcliente SET nombrecliente='"+ocliente.getNombre()+"',apellido='"+ocliente.getApellido()+"',direccliente='"+ocliente.getDireccion()+"' ,fechanac='"+ocliente.getFecha_Nacimiento()+"',telfcliente='"+ocliente.getTelefono()+"',correocliente='"+ocliente.getCorreo()+"',clavecliente='"+ocliente.getClave()+"' WHERE cedulacliente='"+ocliente.getCedula()+"';";
        if(this.cBaseDatos.execUpdate(sql))
        {
            strResult = "Cliente Modificado Correctamente";
        }
        else
        {
            strResult = "No se pudo modificar al cliente";
        }
        return strResult;
    }
    
    
    
    
    
    

    
    public Integer CalcularEdad(String Fecha){ 
    java.util.Date FechaNac=null;
        try {
            /**Se puede cambiar la mascara por el formato de la fecha
            que se quiera recibir, por ejemplo año mes día "yyyy-MM-dd"
            en este caso es día mes año*/
            FechaNac = new SimpleDateFormat("yyyy-MM-dd").parse(Fecha);
        } catch (Exception ex) {
            System.out.println("Error:"+ex);
        }
        Calendar FechaNacimiento = Calendar.getInstance();
        //Se crea un objeto con la fecha actual
        Calendar FechaActual = Calendar.getInstance();
        //Se asigna la fecha recibida a la fecha de nacimiento.
        FechaNacimiento.setTime(FechaNac);
        //Se restan la fecha actual y la fecha de nacimiento
        int Año = FechaActual.get(Calendar.YEAR)- FechaNacimiento.get(Calendar.YEAR);
        int Mes =FechaActual.get(Calendar.MONTH)- FechaNacimiento.get(Calendar.MONTH);
        int Dia = FechaActual.get(Calendar.DATE)- FechaNacimiento.get(Calendar.DATE);
        //Se ajusta el año dependiendo el mes y el día
        if(Mes<0 || (Mes==0 && Dia<0)){
            Año--;
        }
        //Regresa la edad en base a la fecha de nacimiento
        return Año;
    }
    

}
