package com.muebleriaalvarez.clases;

import com.muebleriaalvarez.basedatos.cBaseDatos;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author User
 */
public class cConexionAcdatos {
    
    public Boolean conectar()
        {
          
           cBaseDatos datos =new cBaseDatos();
            return datos.conectar();
            
            
        }
}
