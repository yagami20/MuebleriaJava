/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.muebleriaalvarez.clases;

/**
 *
 * @author yagami20
 */
public class Proveedor {

    public String getRuc() {
        return ruc;
    }

    public void setRuc(String ruc) {
        this.ruc = ruc;
    }

    public String getNombreempresa() {
        return nombreempresa;
    }

    public void setNombreempresa(String nombreempresa) {
        this.nombreempresa = nombreempresa;
    }

    public String getDirecproveedor() {
        return direcproveedor;
    }

    public void setDirecproveedor(String direcproveedor) {
        this.direcproveedor = direcproveedor;
    }

    public String getCorreoproveedor() {
        return correoproveedor;
    }

    public void setCorreoproveedor(String correoproveedor) {
        this.correoproveedor = correoproveedor;
    }

    public String getTelefproveedor() {
        return telefproveedor;
    }

    public void setTelefproveedor(String telefproveedor) {
        this.telefproveedor = telefproveedor;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }
    
 private String ruc;
 private String nombreempresa;
 private String direcproveedor;
 private String correoproveedor;
 private String telefproveedor;
 private String estado="ACTIVO";
 
    
}
