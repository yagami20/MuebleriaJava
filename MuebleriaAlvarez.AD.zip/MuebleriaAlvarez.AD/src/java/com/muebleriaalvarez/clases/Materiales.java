/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.muebleriaalvarez.clases;

import com.muebleriaalvarez.basedatos.cBaseDatos;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author WinUser
 */
public class Materiales {
    private cBaseDatos Bd;
    private ArrayList<Material> ArralMateriales;
    
    public Materiales(){}
    
    public ArrayList<Material> listarMaterial()
    {
        this.ArralMateriales=null;
        if (this.Bd == null)
        {
            this.Bd = new cBaseDatos();
        }
        
        String sql = "SELECT * FROM tblmaterial";
        ResultSet rs = this.Bd.execSQL(sql);
        if(rs != null )
        {
            this.ArralMateriales = new ArrayList<>();
            try
            {
               while(rs.next()) 
               {
                   Material oMaterial = new Material();
                   oMaterial.setIdMaterial(rs.getInt("idmaterial"));
                   oMaterial.setNombreMaterial(rs.getString("nombmaterial"));
                   
                   this.ArralMateriales.add(oMaterial);
               }
            }
            catch (SQLException ex) 
            {
                Logger.getLogger(Materiales.class.getName()).log(Level.SEVERE, null, ex);                       
            }
        }
      return this.ArralMateriales;
    }
}
