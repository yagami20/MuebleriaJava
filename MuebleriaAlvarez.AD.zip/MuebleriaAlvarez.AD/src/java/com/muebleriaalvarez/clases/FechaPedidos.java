/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.muebleriaalvarez.clases;

import com.muebleriaalvarez.basedatos.cBaseDatos;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author User
 */
public class FechaPedidos {
    
     private cBaseDatos bd;
    private ArrayList<FechaPedido> arrayFechapedidos;
    
    public ArrayList<FechaPedido>listarPedidosporfecha(String fecha) {
          this.arrayFechapedidos=null;
        if (this.bd == null)
        {
            this.bd = new cBaseDatos();
        }
        String sql = "SELECT tblcliente.nombrecliente, tblcliente.cedulacliente,tblpedido.idpedido, tblpedido.totalpedido,tblestado.nombestado,tblfechapedido.fechapedido FROM tblcliente inner join tblfechapedido on tblcliente.cedulacliente=tblfechapedido.cedcliente inner join tblpedido on tblfechapedido.idpedido=tblpedido.idpedido inner join tblestado on  tblpedido.idestado=tblestado.idestado WHERE tblfechapedido.fechapedido='"+ fecha +"';";   
        ResultSet rs = this.bd.execSQL(sql);
        if (rs != null) {
            this.arrayFechapedidos = new ArrayList<>();
            try {
                while (rs.next()) {
                    FechaPedido ofecha = new FechaPedido();
                    ofecha.setCedula(rs.getString("cedulacliente"));
                    ofecha.setNombreCliente(rs.getString("nombrecliente"));
                    ofecha.setIdPedido(rs.getInt("idpedido"));
                    ofecha.setTotal(rs.getDouble("totalpedido"));
                    ofecha.setNombreestado(rs.getString("nombestado"));
                    ofecha.setFechaPedido(rs.getString("fechapedido"));
                    this.arrayFechapedidos.add(ofecha);
                }
            } catch (SQLException ex) {
                Logger.getLogger(Materiales.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return this.arrayFechapedidos;
    }

    
}
