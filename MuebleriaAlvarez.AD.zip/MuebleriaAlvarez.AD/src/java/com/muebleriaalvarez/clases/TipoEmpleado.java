/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.muebleriaalvarez.clases;

import com.muebleriaalvarez.basedatos.cBaseDatos;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author erika
 */
public class TipoEmpleado {
    
    private cBaseDatos bd;
    private ArrayList<Empleado> arrEmpleados;
    
    public TipoEmpleado(){}
    
    public ArrayList<Empleado> listarEmpleado()
    {
        this.arrEmpleados=null;
        if (this.bd == null)
        {
            this.bd = new cBaseDatos();
        }
        
        String sql = "SELECT * FROM tbltipoempleado";
        ResultSet rs = this.bd.execSQL(sql);
        if(rs != null )
        {
            this.arrEmpleados = new ArrayList<>();
            try
            {
               while(rs.next()) 
               {
                   Empleado oE=new Empleado();
                   oE.setTipo(rs.getInt("idtipoempleado"));
                   oE.setNombreTipo(rs.getString("nombtipo"));
                                      
                   this.arrEmpleados.add(oE);
               }
            }
            catch (SQLException ex) 
            {
                Logger.getLogger(Empleados.class.getName()).log(Level.SEVERE, null, ex);                       
            }
        }
      return this.arrEmpleados;
    }
}
