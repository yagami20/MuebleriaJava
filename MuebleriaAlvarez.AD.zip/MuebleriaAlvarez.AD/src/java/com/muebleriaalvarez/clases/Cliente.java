package com.muebleriaalvarez.clases;



public class Cliente {
    
private String cedula;
private String nombre;
private String apellido;
private String direccion;
private String telefono;
private String correo;
private String clave;
private String fecha_Nacimiento;
private String estado;

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getEstado() {
        return estado;
    }

    public String getCedula() {
        return cedula;
    }

    public String getNombre() {
        return nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public String getDireccion() {
        return direccion;
    }

    public String getTelefono() {
        return telefono;
    }

    public String getCorreo() {
        return correo;
    }

    public String getClave() {
        return clave;
    }

    public String getFecha_Nacimiento() {
        return fecha_Nacimiento;
    }

    public void setCedula(String cedula) {
        this.cedula = cedula;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre.toUpperCase();
    }

    public void setApellido(String apellido) {
        this.apellido = apellido.toUpperCase();
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion.toUpperCase();
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public void setClave(String clave) {
        this.clave = clave;
    }

    public void setFecha_Nacimiento(String fecha_Nacimiento) {
        this.fecha_Nacimiento = fecha_Nacimiento;
    }

    

    


}
