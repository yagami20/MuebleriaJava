/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.muebleriaalvarez.clases;

import com.muebleriaalvarez.basedatos.cBaseDatos;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author User
 */
public class DetallePedidos {
    
     private cBaseDatos bd;
    private ArrayList<DetallePedido> DetallePedido;

    public ArrayList<DetallePedido> getDetallePedido() {
        return DetallePedido;
    }
    
    
    public Integer contarNumeroProductos(String codigoproducto ){
   
        Integer contarNumeroProductos=0;
                if (this.bd == null) {
            this.bd = new cBaseDatos();
        }

        String strSql = "select count(*) as numero from tbldetallepedido  WHERE codproducto='" + codigoproducto + "';";
        ResultSet rs = this.bd.execSQL(strSql);
           if (rs != null) {
          
            try {
                while (rs.next()) {
                  contarNumeroProductos=rs.getInt("numero"); 
                }
            } catch (SQLException ex) {
                Logger.getLogger(Materiales.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
       
        return contarNumeroProductos;
    
    }
}
