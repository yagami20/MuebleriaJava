/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.muebleriaalvarez.clases;

import java.text.SimpleDateFormat;
import java.util.Calendar;

/**
 *
 * @author User
 */
public class Empleado {

    private String cedula;
    private String nombre;
    private String apellido;
    private String direccion;
    private String fechaNacimiento;
    private String telefono;
    private Double salario;
    private Integer tipo;
    private String correo;
    private String clave;
    private String estado;
    private String nombreTipo;

    public void setNombreTipo(String nombreTipo) {
        this.nombreTipo = nombreTipo;
    }

    public String getNombreTipo() {
        return nombreTipo;
    }

      public void setCedula(String cedula) {
        this.cedula = cedula;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public void setFechaNacimiento(String fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public void setSalario(Double salario) {
        this.salario = salario;
    }

    public void setTipo(Integer tipo) {
        this.tipo = tipo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public void setClave(String clave) {
        this.clave = clave;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    
    
    public String getCedula() {
        return cedula;
    }

    public String getNombre() {
        return nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public String getDireccion() {
        return direccion;
    }

    public String getFechaNacimiento() {
        return fechaNacimiento;
    }

    public String getTelefono() {
        return telefono;
    }

    public Double getSalario() {
        return salario;
    }

    public Integer getTipo() {
        return tipo;
    }

    public String getCorreo() {
        return correo;
    }

    public String getClave() {
        return clave;
    }

    public String getEstado() {
        return estado;
    }
    
     public Integer CalcularEdad(String Fecha){ 
    java.util.Date FechaNac=null;
        try {
            /**Se puede cambiar la mascara por el formato de la fecha
            que se quiera recibir, por ejemplo año mes día "yyyy-MM-dd"
            en este caso es día mes año*/
            FechaNac = new SimpleDateFormat("yyyy-MM-dd").parse(Fecha);
        } catch (Exception ex) {
            System.out.println("Error:"+ex);
        }
        Calendar FechaNacimiento = Calendar.getInstance();
        //Se crea un objeto con la fecha actual
        Calendar FechaActual = Calendar.getInstance();
        //Se asigna la fecha recibida a la fecha de nacimiento.
        FechaNacimiento.setTime(FechaNac);
        //Se restan la fecha actual y la fecha de nacimiento
        int Año = FechaActual.get(Calendar.YEAR)- FechaNacimiento.get(Calendar.YEAR);
        int Mes =FechaActual.get(Calendar.MONTH)- FechaNacimiento.get(Calendar.MONTH);
        int Dia = FechaActual.get(Calendar.DATE)- FechaNacimiento.get(Calendar.DATE);
        //Se ajusta el año dependiendo el mes y el día
        if(Mes<0 || (Mes==0 && Dia<0)){
            Año--;
        }
        //Regresa la edad en base a la fecha de nacimiento
        return Año;
    }

}
