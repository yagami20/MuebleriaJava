/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.muebleriaalvarez.clases;


public class Producto {
    
    private String codigoProducto;
    private Integer idProducto;
    private String nombreProducto;
    private Integer materialProducto;
    private Integer categoriaProducto;
    private Integer colorProducto;
    private Double precioProducto;
    private Integer stockProducto;
    private String descripcionProducto;
    private String nombreCategoria;
    private String nombreMaterial;
    private String nombreColor;
    private String estado;
    
    public Producto(){}

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getEstado() {
        return estado;
    }

    
    public String getCodigoProducto() {
        return codigoProducto;
    }

    public String getNombreCategoria() {
        return nombreCategoria;
    }

    public String getNombreMaterial() {
        return nombreMaterial;
    }

    public String getNombreColor() {
        return nombreColor;
    }

    public void setCodigoProducto(String codigoProducto) {
        this.codigoProducto = codigoProducto;
    }

    public void setNombreCategoria(String nombreCategoria) {
        this.nombreCategoria = nombreCategoria;
    }

    public void setNombreMaterial(String nombreMaterial) {
        this.nombreMaterial = nombreMaterial;
    }

    public void setNombreColor(String nombreColor) {
        this.nombreColor = nombreColor;
    }
    
    
    

    public Integer getIdProducto() {
        return idProducto;
    }

    public void setCodigoproducto(String codigoproducto) {
        this.codigoProducto = codigoproducto;
    }

    public void setIdProducto(Integer idProducto) {
        this.idProducto = idProducto;
    }

    public String getNombreProducto() {
        return nombreProducto;
    }

    public void setNombreProducto(String nombreProducto) {
        this.nombreProducto = nombreProducto;
    }

    public Integer getMaterialProducto() {
        return materialProducto;
    }

    public void setMaterialProducto(Integer materialProducto) {
        this.materialProducto = materialProducto;
    }

    public Integer getCategoriaProducto() {
        return categoriaProducto;
    }

    public void setCategoriaProducto(Integer categoriaProducto) {
        this.categoriaProducto = categoriaProducto;
    }

    public Integer getColorProducto() {
        return colorProducto;
    }

    public void setColorProducto(Integer colorProducto) {
        this.colorProducto = colorProducto;
    }

    public Double getPrecioProducto() {
        return precioProducto;
    }

    public void setPrecioProducto(Double precioProducto) {
        this.precioProducto = precioProducto;
    }

    public Integer getStockProducto() {
        return stockProducto;
    }

    public void setStockProducto(Integer stockProducto) {
        this.stockProducto = stockProducto;
    }

    public String getDescripcionProducto() {
        return descripcionProducto;
    }

    public void setDescripcionProducto(String descripcionProducto) {
        this.descripcionProducto = descripcionProducto;
    }

    
 
    
    
}
