/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.muebleriaalvarez.clases;

/**
 *
 * @author User
 */
public class DetallePedido {
    
    private Integer idPedido;
    private String codigoProducto;
    private Integer cantidad;

    public Integer getIdPedido() {
        return idPedido;
    }

    public void setCodigoProducto(String codigoProducto) {
        this.codigoProducto = codigoProducto;
    }

  

    public Integer getCantidad() {
        return cantidad;
    }

    public void setIdPedido(Integer idPedido) {
        this.idPedido = idPedido;
    }

    public String getCodigoProducto() {
        return codigoProducto;
    }

  

    public void setCantidad(Integer cantidad) {
        this.cantidad = cantidad;
    }
    
    
}
