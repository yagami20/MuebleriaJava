/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.muebleriaalvarez.clases;

/**
 *
 * @author WinUser
 */
public class Color {
    private Integer idColor;
    private String nombreColor;

    public Integer getIdColor() {
        return idColor;
    }

    public void setIdColor(Integer idColor) {
        this.idColor = idColor;
    }

    public String getNombreColor() {
        return nombreColor.toUpperCase();
    }

    public void setNombreColor(String nombreColor) {
        this.nombreColor = nombreColor.toUpperCase();
    }
    
    
}
