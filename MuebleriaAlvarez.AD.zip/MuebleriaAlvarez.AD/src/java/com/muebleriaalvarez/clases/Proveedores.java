/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.muebleriaalvarez.clases;

import com.muebleriaalvarez.basedatos.cBaseDatos;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author yagami20
 */
public class Proveedores {
    
    private cBaseDatos bd;
    private ArrayList<Proveedor> arrayProveedores;
    //private ArrayList<Proveedor> arrayEstado;

   public Proveedores(){
   
   }
    
public String ingresarProveedor(Proveedor oProveedor)
        {
        String strResult="error";
        int band=0;
        if (this.bd == null) {
            this.bd = new cBaseDatos();
        }
         
        String srtSql="SELECT * FROM tblproveedor WHERE ruc='"+oProveedor.getRuc()+"';";
        ResultSet rs=this.bd.execSQL(srtSql);
        if(rs!=null)
        {
            try{
                while(rs.next())
                {
                    band=band+1;
                }
            }catch (SQLException ex) {
                Logger.getLogger(Proveedores.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
         if(band>=1)
         {
             strResult="si existe";
         }
         else
         {
         String sql = "INSERT INTO tblproveedor(ruc,nombreempresa,direcproveedor,correoproveedor,telefproveedor,estado) VALUES ('"+oProveedor.getRuc()+"','"+oProveedor.getNombreempresa()+"','"+oProveedor.getDirecproveedor()+"','"+oProveedor.getCorreoproveedor()+"','"+oProveedor.getTelefproveedor()+"','"+oProveedor.getEstado()+"');";
         
                  
            if (this.bd.execUpdate(sql))
            {
                //if(this.cBaseDatos.execUpdate(sql1))
                //{
                    strResult = "Proveedor Ingresado";
                //}
            }
            else
            {
                strResult = "No hay conexion con la base de datos";
            }
         }
        
        return strResult;
        }
    
   
  /*   
public ArrayList<Proveedor> listarProveedores() {
          this.arrayProveedores=null;
        if (this.bd == null)
        {
            this.bd = new cBaseDatos();
        }
        
        String sql = "SELECT * FROM tblproveedor";
        ResultSet rs = this.bd.execSQL(sql);
        if (rs != null) {
            this.arrayProveedores = new ArrayList<>();
            try {
                while (rs.next()) {
                    Proveedor oProveedor = new Proveedor();
                    oProveedor.setRuc(rs.getString("ruc"));
                    oProveedor.setNombreempresa(rs.getString("nombreempresa"));
                    oProveedor.setDirecproveedor(rs.getString("direcproveedor"));
                    oProveedor.setCorreoproveedor(rs.getString("correoproveedor"));
                    oProveedor.setTelefproveedor(rs.getString("telefproveedor"));
                    oProveedor.setEstado(rs.getString("estado"));

                    this.arrayProveedores.add(oProveedor);
                }
            } catch (SQLException ex) {
                Logger.getLogger(Materiales.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return this.arrayProveedores; 
    } */
} 


