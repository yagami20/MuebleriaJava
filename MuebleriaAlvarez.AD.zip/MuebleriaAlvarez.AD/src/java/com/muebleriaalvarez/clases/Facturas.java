/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.muebleriaalvarez.clases;

import com.muebleriaalvarez.basedatos.cBaseDatos;
import java.util.ArrayList;

/**
 *
 * @author Erika Reina
 */
public class Facturas {
    private cBaseDatos bd;
    
    
    public String ingresarFactura(Factura oFactura)
    {
        String strResult;
        if (this.bd == null) {
            this.bd = new cBaseDatos();
        }
        
        String sql = "INSERT INTO tblfactura(idfactura,fechfactura,cedcliente,idestado,pordescuento,descuento,igv,subtotalfac,totalpagar,estado) VALUES (default,'"+oFactura.getFechFactura()+"','"+oFactura.getCedula()+"','"+oFactura.getIdEstad()+"','"+oFactura.getPorDescuento()+"','"+oFactura.getDescuento()+"','"+oFactura.getIgv()+"','"+oFactura.getSubTotal()+"','"+oFactura.getTotalpagar()+"','"+oFactura.getNomEstad()+"');";
        
        if(this.bd.execUpdate(sql))
        {
            strResult = "Factura Registrada";
        }
        else
        {
            strResult = "No hay conexion con la base de Datos";
        }
        return strResult;
    }
    
}
