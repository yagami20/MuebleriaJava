
package com.muebleriaAlavarezWS.LogicaNegocio;

import com.muebleriaalvarezwsacdatos.Categoria;
import com.muebleriaalvarezwsacdatos.MuebleriaAlvarezWSAcdatos_Service;
import com.muebleriaalvarezwsacdatos.Producto;
import com.muebleriaalvarezwsacdatos.Factura;
import com.muebleriaalvarezwsacdatos.Cliente;
import com.muebleriaalvarezwsacdatos.Empleado;
import com.muebleriaalvarezwsacdatos.Exception_Exception;
import com.muebleriaalvarezwsacdatos.Proveedor;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.xml.ws.WebServiceRef;

/**
 *
 * @author Jennifer
 */
@WebService(serviceName = "muebleriaAlvarezWSLogicaNegocio")
public class muebleriaAlvarezWSLogicaNegocio {

    @WebServiceRef(wsdlLocation = "WEB-INF/wsdl/localhost_8080/MuebleriaAlvarez.AD/muebleriaAlvarezWSAcdatos.wsdl")
    private MuebleriaAlvarezWSAcdatos_Service service;

    @WebMethod(operationName = "registrarProductoLogNegocio")
    public String registrarProductoLogNegocio(Producto oProducto) {
        com.muebleriaalvarezwsacdatos.MuebleriaAlvarezWSAcdatos port = service.getMuebleriaAlvarezWSAcdatosPort();
        String strResult = port.registrarProductoAcdatos(oProducto);
        return strResult;
    }

    @WebMethod(operationName = "registrarCategoriaLogNegocio")
    public String registrarCategoriaLogNegocio(Categoria oCategoria) {
        com.muebleriaalvarezwsacdatos.MuebleriaAlvarezWSAcdatos port = service.getMuebleriaAlvarezWSAcdatosPort();
        String strResult = port.registrarCategoriaAcdatos(oCategoria);
        return strResult;
    }

    public java.util.List<com.muebleriaalvarezwsacdatos.Color> listarColorLN() {
        // Note that the injected javax.xml.ws.Service reference as well as port objects are not thread safe.
        // If the calling of port operations may lead to race condition some synchronization is required.
        com.muebleriaalvarezwsacdatos.MuebleriaAlvarezWSAcdatos port = service.getMuebleriaAlvarezWSAcdatosPort();
        return port.listarColorAD();
    }

    public java.util.List<com.muebleriaalvarezwsacdatos.Material> listarMaterialLN() {
        // Note that the injected javax.xml.ws.Service reference as well as port objects are not thread safe.
        // If the calling of port operations may lead to race condition some synchronization is required.
        com.muebleriaalvarezwsacdatos.MuebleriaAlvarezWSAcdatos port = service.getMuebleriaAlvarezWSAcdatosPort();
        return port.listarMaterialAD();
    }

    public java.util.List<com.muebleriaalvarezwsacdatos.Categoria> listarCategoriaLN() {
        // Note that the injected javax.xml.ws.Service reference as well as port objects are not thread safe.
        // If the calling of port operations may lead to race condition some synchronization is required.
        com.muebleriaalvarezwsacdatos.MuebleriaAlvarezWSAcdatos port = service.getMuebleriaAlvarezWSAcdatosPort();
        return port.listarCategoriaAD();
    }

    private String registrarCategoriaAcdatos(com.muebleriaalvarezwsacdatos.Categoria arg0) {
        // Note that the injected javax.xml.ws.Service reference as well as port objects are not thread safe.
        // If the calling of port operations may lead to race condition some synchronization is required.
        com.muebleriaalvarezwsacdatos.MuebleriaAlvarezWSAcdatos port = service.getMuebleriaAlvarezWSAcdatosPort();
        return port.registrarCategoriaAcdatos(arg0);
    }

    @WebMethod(operationName = "ingresarCliente")
    public String ingresarCliente(Cliente oC) {
        com.muebleriaalvarezwsacdatos.MuebleriaAlvarezWSAcdatos port = service.getMuebleriaAlvarezWSAcdatosPort();
        String strResult = port.ingresarCliente(oC);
        return strResult;
    }

    @WebMethod(operationName = "getClientesADWS")
    public java.util.List<com.muebleriaalvarezwsacdatos.Cliente> getClientesADWS() {
        // Note that the injected javax.xml.ws.Service reference as well as port objects are not thread safe.
        // If the calling of port operations may lead to race condition some synchronization is required.
        com.muebleriaalvarezwsacdatos.MuebleriaAlvarezWSAcdatos port = service.getMuebleriaAlvarezWSAcdatosPort();
        return port.getClientesADWS();

    }

    @WebMethod(operationName = "buscarClientesADWS")
    public Cliente buscarClientesADWS(String cedula) {
        // Note that the injected javax.xml.ws.Service reference as well as port objects are not thread safe.
        // If the calling of port operations may lead to race condition some synchronization is required.
        com.muebleriaalvarezwsacdatos.MuebleriaAlvarezWSAcdatos port = service.getMuebleriaAlvarezWSAcdatosPort();
        return port.buscarClientesADWS(cedula);
    }

    @WebMethod(operationName = "eliminarClientesADWS")
    public String eliminarClientesADWS(String cedula) {
        // Note that the injected javax.xml.ws.Service reference as well as port objects are not thread safe.
        // If the calling of port operations may lead to race condition some synchronization is required.
        com.muebleriaalvarezwsacdatos.MuebleriaAlvarezWSAcdatos port = service.getMuebleriaAlvarezWSAcdatosPort();
        return port.eliminarClientesADWS(cedula);
    }

    @WebMethod(operationName = "modificarclienteLogNegocio")
    public String modificarclienteLogNegocio(Cliente ocliente) {
        // Note that the injected javax.xml.ws.Service reference as well as port objects are not thread safe.
        // If the calling of port operations may lead to race condition some synchronization is required.
        com.muebleriaalvarezwsacdatos.MuebleriaAlvarezWSAcdatos port = service.getMuebleriaAlvarezWSAcdatosPort();
        String strResult = port.modificardatosclientes(ocliente);
        return strResult;
    }

    @WebMethod(operationName = "contarProductosPedidosLN")
    public Integer contarProductosPedidosLN(String codipoproducto) {
        // Note that the injected javax.xml.ws.Service reference as well as port objects are not thread safe.
        // If the calling of port operations may lead to race condition some synchronization is required.
        com.muebleriaalvarezwsacdatos.MuebleriaAlvarezWSAcdatos port = service.getMuebleriaAlvarezWSAcdatosPort();
        return port.contarProductosPedidosAD(codipoproducto);
    }

    @WebMethod(operationName = "listarProductosLN")
    public java.util.List<com.muebleriaalvarezwsacdatos.Producto> listarProductosLN() {
        // Note that the injected javax.xml.ws.Service reference as well as port objects are not thread safe.
        // If the calling of port operations may lead to race condition some synchronization is required.
        com.muebleriaalvarezwsacdatos.MuebleriaAlvarezWSAcdatos port = service.getMuebleriaAlvarezWSAcdatosPort();
        return port.listarProductosAD();
    }

    @WebMethod(operationName = "buscarProductosCodigoAD")
    public Producto buscarProductosCodigoAD(String codigoProducto) {
        // Note that the injected javax.xml.ws.Service reference as well as port objects are not thread safe.
        // If the calling of port operations may lead to race condition some synchronization is required.
        com.muebleriaalvarezwsacdatos.MuebleriaAlvarezWSAcdatos port = service.getMuebleriaAlvarezWSAcdatosPort();
        return port.buscarProductosCodigoAD(codigoProducto);
    }
     @WebMethod(operationName = "eliminarProductoCambioLN")
    public String eliminarProductoCambioLN(String codigoProducto) {
        // Note that the injected javax.xml.ws.Service reference as well as port objects are not thread safe.
        // If the calling of port operations may lead to race condition some synchronization is required.
        com.muebleriaalvarezwsacdatos.MuebleriaAlvarezWSAcdatos port = service.getMuebleriaAlvarezWSAcdatosPort();
        return port.eliminarProductoCambioAD(codigoProducto);
    }
    
    @WebMethod(operationName = "modificarDatosProductosLN")
    public String modificarDatosProductosLN(Producto oproducto) {
        // Note that the injected javax.xml.ws.Service reference as well as port objects are not thread safe.
        // If the calling of port operations may lead to race condition some synchronization is required.
        com.muebleriaalvarezwsacdatos.MuebleriaAlvarezWSAcdatos port = service.getMuebleriaAlvarezWSAcdatosPort();
        return port.modificarDatosProductosAC(oproducto);
    }
    
     @WebMethod(operationName = "eliminarProductoLN")
    public String eliminarProductoLN(String codigoProducto) {
        // Note that the injected javax.xml.ws.Service reference as well as port objects are not thread safe.
        // If the calling of port operations may lead to race condition some synchronization is required.
        com.muebleriaalvarezwsacdatos.MuebleriaAlvarezWSAcdatos port = service.getMuebleriaAlvarezWSAcdatosPort();
        return port.eliminarProductoAD(codigoProducto);
    }

    public java.util.List<com.muebleriaalvarezwsacdatos.Producto> listarProductosStockminimoLN(Integer stock) {
        // Note that the injected javax.xml.ws.Service reference as well as port objects are not thread safe.
        // If the calling of port operations may lead to race condition some synchronization is required.
        com.muebleriaalvarezwsacdatos.MuebleriaAlvarezWSAcdatos port = service.getMuebleriaAlvarezWSAcdatosPort();
        return port.listarProductosStockminimoAD(stock);
    }

    public java.util.List<com.muebleriaalvarezwsacdatos.Empleado> listarEmpleadosLN() {
        // Note that the injected javax.xml.ws.Service reference as well as port objects are not thread safe.
        // If the calling of port operations may lead to race condition some synchronization is required.
        com.muebleriaalvarezwsacdatos.MuebleriaAlvarezWSAcdatos port = service.getMuebleriaAlvarezWSAcdatosPort();
        return port.listarEmpleadosAD();
    }

    public String eliminarEmpleadoLN(String cedula) {
        // Note that the injected javax.xml.ws.Service reference as well as port objects are not thread safe.
        // If the calling of port operations may lead to race condition some synchronization is required.
        com.muebleriaalvarezwsacdatos.MuebleriaAlvarezWSAcdatos port = service.getMuebleriaAlvarezWSAcdatosPort();
        return port.eliminarEmpleadoAD(cedula);
    }

    public Empleado buscarEmpleadoCodigoLN(String cedula) {
                com.muebleriaalvarezwsacdatos.MuebleriaAlvarezWSAcdatos port = service.getMuebleriaAlvarezWSAcdatosPort();
        return port.buscarEmpleadoCodigoAD(cedula);
    }
    
   @WebMethod(operationName = "ingresarEmpleado")
    public String ingresarEmpleado(Empleado oE) {
       
        com.muebleriaalvarezwsacdatos.MuebleriaAlvarezWSAcdatos port = service.getMuebleriaAlvarezWSAcdatosPort();
        String strResult = port.ingresarEmpleado(oE);
        return strResult;
    }

    @WebMethod(operationName = "listarTipoEmpleado")
    public java.util.List<com.muebleriaalvarezwsacdatos.Empleado> listarTipoEmpleado() {
        
        com.muebleriaalvarezwsacdatos.MuebleriaAlvarezWSAcdatos port = service.getMuebleriaAlvarezWSAcdatosPort();
        return port.listarTipoEmpleado();
    }

    public java.util.List<com.muebleriaalvarezwsacdatos.FechaPedido> listarPedidosfechaLN(String fecha) {
        // Note that the injected javax.xml.ws.Service reference as well as port objects are not thread safe.
        // If the calling of port operations may lead to race condition some synchronization is required.
        com.muebleriaalvarezwsacdatos.MuebleriaAlvarezWSAcdatos port = service.getMuebleriaAlvarezWSAcdatosPort();
        return port.listarPedidosfechaAD(fecha);
    }

    public Boolean verificarConexionLN() {
        // Note that the injected javax.xml.ws.Service reference as well as port objects are not thread safe.
        // If the calling of port operations may lead to race condition some synchronization is required.
        com.muebleriaalvarezwsacdatos.MuebleriaAlvarezWSAcdatos port = service.getMuebleriaAlvarezWSAcdatosPort();
        return port.verificarConexionAD();
    }

    public Cliente auntentificarClienteLN(String cedula, String clave) {
        // Note that the injected javax.xml.ws.Service reference as well as port objects are not thread safe.
        // If the calling of port operations may lead to race condition some synchronization is required.
        com.muebleriaalvarezwsacdatos.MuebleriaAlvarezWSAcdatos port = service.getMuebleriaAlvarezWSAcdatosPort();
        return port.auntentificarClienteAD(cedula, clave);
    }

    public String desencriptarLN(String key,String iv,String textoencriptar) throws Exception_Exception {
        // Note that the injected javax.xml.ws.Service reference as well as port objects are not thread safe.
        // If the calling of port operations may lead to race condition some synchronization is required.
        com.muebleriaalvarezwsacdatos.MuebleriaAlvarezWSAcdatos port = service.getMuebleriaAlvarezWSAcdatosPort();
        return port.desencriptarAD(key, iv, textoencriptar);
    }

    public String encriptarLN(String key, String iv, String textodesencriptar) throws Exception_Exception {
        // Note that the injected javax.xml.ws.Service reference as well as port objects are not thread safe.
        // If the calling of port operations may lead to race condition some synchronization is required.
        com.muebleriaalvarezwsacdatos.MuebleriaAlvarezWSAcdatos port = service.getMuebleriaAlvarezWSAcdatosPort();
        return port.encriptarAD(key, iv, textodesencriptar);
    }
    
     @WebMethod(operationName = "ingresarFactura")
    public String ingresarFactura(Factura oF) {
       
        com.muebleriaalvarezwsacdatos.MuebleriaAlvarezWSAcdatos port = service.getMuebleriaAlvarezWSAcdatosPort();
        return port.ingresarFacturaAD(oF);
    }
    
       @WebMethod(operationName = "ingresarProveedorLN")
    public String ingresarProveedorLN(Proveedor oP) {
       
        com.muebleriaalvarezwsacdatos.MuebleriaAlvarezWSAcdatos port = service.getMuebleriaAlvarezWSAcdatosPort();
        String strResult = port.ingresarProveedorAD(oP);
        return strResult;
    }
    
    
      @WebMethod(operationName = "modificarEmpleadoLN")
    public String modificarEmpleadoLN(Empleado oEmpleado) {
        com.muebleriaalvarezwsacdatos.MuebleriaAlvarezWSAcdatos port = service.getMuebleriaAlvarezWSAcdatosPort();
        return port.modificarEmpleadoAD(oEmpleado);
    }
 
    
    //empleado
     public Empleado auntentificarEmpleadoLN(String cedula, String clave, Integer idtipo) {
        // Note that the injected javax.xml.ws.Service reference as well as port objects are not thread safe.
        // If the calling of port operations may lead to race condition some synchronization is required.
        com.muebleriaalvarezwsacdatos.MuebleriaAlvarezWSAcdatos port = service.getMuebleriaAlvarezWSAcdatosPort();
        return port.auntentificarEmpleadoAD(cedula, clave, idtipo);
    }

    
}
