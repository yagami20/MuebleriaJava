$(document).ready(function(){
//$("#banner").css({"height":$(window).height() + "px"});

var flag=false;
var scroll;
$(window).scroll(function(){
scroll=$(window).scrollTop();
	if (scroll>50) {
		if (!flag) {
		 $("#logo").css({"margin-top":"-8px","width":"250px","height":"60px"})
		 $("header").css({"background-color":"#3C3C3C"});
		 flag=true;
		}
	} else {
		if (flag) {
				 $("#logo").css({"margin-top":"100px","width":"400px","height":"100px"})
			$("header").css({"background-color":"3C3C3C"});
                        $("img").css({" z-index:":"20"});
                         
			flag=false;
			}
	}

	});

});