
function validar() {
	var estaTodoOK = true;	
        var cedula=document.getElementById("cedula").value
	var clave=document.getElementById("clave").value

	
	if ((document.getElementById("cedula").value.length)==0) {
		estaTodoOK=false;
	}

	if (document.getElementById("clave").value.length==0) {
		estaTodoOK = false;	
	}
	
	if (!estaTodoOK) {
		alert("DATOS  VUELVA A REVISAR ANTES DE ENVIAR");	
	}
	
	
	return estaTodoOK;
}

function entroEnFoco(elemento) {
	elemento.className='enfoco';
}

function salioDeFoco(elemento) {
	elemento.className='';
	
}

function soloLetras(e) { 
tecla = (document.all) ? e.keyCode : e.which; 
if (tecla==8) return true; //Tecla de retroceso (para poder borrar) 
// dejar la lÃ­nea de patron que se necesite y borrar el resto 
patron =/[A-Za-z\sáéíóú]/; // Solo acepta letras 
//patron = /\d/; // Solo acepta nÃºmeros 
//patron = /\w/; // Acepta nÃºmeros y letras 
//patron = /\D/; // No acepta nÃºmeros 
// 
te = String.fromCharCode(tecla); 
return patron.test(te); 
} 
      
   function soloNumeros(e){
	var key = window.Event ? e.which : e.keyCode
	return (key >= 48 && key <= 57)
}
function checkTelefono(){
            if (document.form1.txtTelefonoUsuario.value !== "") {
                var tel = document.form1.txtTelefonoUsuario.value;
                array = tel.split("");
                num = array.length;
                if (num < 10)
                {
                    alert("El telefono NO es v\xe1lido verifique los digitos!!!");
                    document.form1.txtTelefonoUsuario.focus();
                    document.form1.txtTelefonoUsuario.value="";
                    return false;
                }
            }
        }
 


